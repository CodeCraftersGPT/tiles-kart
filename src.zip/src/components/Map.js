// define array with numbers
// with map double the numbers

// define array with numbers

const numbers = [1,2,3,4,5,6,7,8,9,10];

// with map double the numbers
const doubleNumbers = numbers.map((number) => number * 2);

console.log(doubleNumbers);// [2,4,6,8,10,12,14,16,18,20]



const booksArray = [
    {
        id: 1,
        name: 'The Alchemist',
        author: 'Paulo Coelho',
        price: 200,
        rating: 4.5
    },
    {
        id: 2,
        name: 'The Monk who sold his Ferrari',
        author: 'Robin Sharma',
        price: 300,
        rating: 4.0
    },
    {
        id: 3,
        name: 'The Secret', 
        author: 'Rhonda Byrne',
        price: 400,
        rating: 4.8
    }];

