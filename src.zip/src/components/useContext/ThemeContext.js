// create the themecontext and export it

// import createContext from react
import { createContext } from "react";

// create the themecontext and export it

const ThemeContext = createContext();

export default ThemeContext;



